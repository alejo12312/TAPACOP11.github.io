let menu = document.querySelector("#menu");
let toggleIicon = document.querySelector("#toggle-icon");

toggleIicon.addEventListener("click", function() {
  menu.classList.toggle("menu-on");
});
